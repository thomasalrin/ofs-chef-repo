cd /usr/local/dev/Petclinic-test/
#java -cp lib/petclinic-test.jar:lib/poi-3.13.jar:lib/selenium-server-standalone-2.48.2.jar:lib/testng-6.9.9.jar org.testng.TestNG TestSuite.xml
/usr/bin/Xvfb :0 -screen 0 1024x768x24
export DISPLAY=:0
#java -cp lib/petclinic-test.jar:lib/poi-3.13.jar:lib/selenium-server-standalone-2.48.2.jar:lib/testng-6.9.9.jar:lib/guice-4.0.jar:lib/velocity-dep-1.4.jar:lib/reportng-1.1.4.jar org.testng.TestNG TestSuite.xml
################################## Run Test 
################################## ##########################################
echo "Begin Test" 
export JAR_HOME=lib/ 
#echo "Set JAR files from " $JAR_HOME 
for f in $JAR_HOME/*.jar
  do
    JAR_CLASSPATH=$JAR_CLASSPATH:$f
 #   echo "Loading JAR " $f
  done 
export JAR_CLASSPATH 
#echo "Run Test" 
java -classpath $JAR_CLASSPATH org.testng.TestNG TestSuite.xml 
cd /usr/local/tomcat/apache-tomcat-6.0.44/webapps/SeleniumReport
sudo chmod +r *
echo "End Test"
################################## Run Test ##########################################
